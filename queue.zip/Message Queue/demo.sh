#!/bin/bash

# Demo script for testing the Message Queue system
# Make sure the producer (npm start) and worker (npm run worker) are running first!

echo "🚀 Message Queue Demo - Testing BullMQ"
echo "======================================"
echo ""

BASE_URL="http://localhost:3000"

# Color codes
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if services are running
echo "Checking if services are running..."
if ! curl -s "$BASE_URL/health" > /dev/null; then
    echo "❌ Producer API is not running. Start it with: npm start"
    exit 1
fi
echo "✅ Producer API is running"
echo ""

# 1. Add an email job
echo -e "${BLUE}1. Adding email job...${NC}"
EMAIL_RESPONSE=$(curl -s -X POST "$BASE_URL/enqueue" \
  -H "Content-Type: application/json" \
  -d '{
    "task": "send-email",
    "data": {
      "to": "john@example.com",
      "subject": "Welcome to BullMQ!",
      "body": "This is a demo of message queues"
    }
  }')
echo "$EMAIL_RESPONSE" | jq '.'
EMAIL_JOB_ID=$(echo "$EMAIL_RESPONSE" | jq -r '.jobId')
echo ""
sleep 1

# 2. Add an image processing job
echo -e "${BLUE}2. Adding image processing job...${NC}"
IMAGE_RESPONSE=$(curl -s -X POST "$BASE_URL/enqueue" \
  -H "Content-Type: application/json" \
  -d '{
    "task": "process-image",
    "data": {
      "imageUrl": "https://example.com/photo.jpg",
      "operations": ["resize", "compress", "watermark"]
    }
  }')
echo "$IMAGE_RESPONSE" | jq '.'
IMAGE_JOB_ID=$(echo "$IMAGE_RESPONSE" | jq -r '.jobId')
echo ""
sleep 1

# 3. Add a report generation job
echo -e "${BLUE}3. Adding report generation job...${NC}"
REPORT_RESPONSE=$(curl -s -X POST "$BASE_URL/enqueue" \
  -H "Content-Type: application/json" \
  -d '{
    "task": "generate-report",
    "data": {
      "reportType": "monthly-sales",
      "dateRange": "2024-01-01 to 2024-01-31"
    }
  }')
echo "$REPORT_RESPONSE" | jq '.'
REPORT_JOB_ID=$(echo "$REPORT_RESPONSE" | jq -r '.jobId')
echo ""
sleep 1

# 4. Add multiple generic tasks
echo -e "${BLUE}4. Adding 3 generic tasks...${NC}"
for i in {1..3}; do
  curl -s -X POST "$BASE_URL/enqueue" \
    -H "Content-Type: application/json" \
    -d "{
      \"task\": \"task-$i\",
      \"data\": {
        \"message\": \"Processing task number $i\",
        \"priority\": \"$i\"
      }
    }" | jq '.'
  sleep 0.5
done
echo ""

# 5. Check queue stats
echo -e "${BLUE}5. Checking queue statistics...${NC}"
curl -s "$BASE_URL/stats" | jq '.'
echo ""
sleep 2

# 6. Check job status
echo -e "${BLUE}6. Checking status of email job (ID: $EMAIL_JOB_ID)...${NC}"
curl -s "$BASE_URL/job/$EMAIL_JOB_ID" | jq '.'
echo ""
sleep 2

# 7. Final stats
echo -e "${BLUE}7. Final queue statistics...${NC}"
curl -s "$BASE_URL/stats" | jq '.'
echo ""

echo -e "${GREEN}======================================"
echo "✅ Demo completed!"
echo ""
echo "💡 Tips:"
echo "  - Watch worker terminal to see job processing"
echo "  - Check job status: curl $BASE_URL/job/<jobId>"
echo "  - Monitor stats: curl $BASE_URL/stats"
echo "======================================${NC}"
