# 🚀 Quick Start Guide

This guide will get you up and running with the Message Queue demo in 3 minutes!

## 1️⃣ Prerequisites Check

Make sure Redis is running:
```bash
redis-cli ping
# Should return: PONG
```

If Redis is not running:
```bash
# Using Docker (recommended):
docker run -d -p 6379:6379 redis:latest

# Or install locally:
# Mac: brew install redis && redis-server
# Ubuntu: sudo apt install redis-server && redis-server
```

## 2️⃣ Install Dependencies

```bash
npm install
```

## 3️⃣ Start the System

### Option A: Run Both at Once (Recommended)
```bash
npm run dev
```

### Option B: Run Separately (Two Terminals)

**Terminal 1 - Producer API:**
```bash
npm start
```

**Terminal 2 - Worker:**
```bash
npm run worker
```

## 4️⃣ Test It!

### Quick Test (CLI Examples)
```bash
npm run examples
```

### Interactive Test (API Demo)
```bash
npm run demo
```

### Manual Test (curl)
```bash
# Add a job
curl -X POST http://localhost:3000/enqueue \
  -H "Content-Type: application/json" \
  -d '{
    "task": "send-email",
    "data": {
      "to": "test@example.com",
      "subject": "Hello BullMQ!"
    }
  }'

# Check stats
curl http://localhost:3000/stats
```

## 🎉 What to Watch

1. **Producer Terminal**: Shows API requests and jobs being added
2. **Worker Terminal**: Shows jobs being processed with progress updates
3. **API Responses**: Returns job IDs you can use to track status

## 🐛 Troubleshooting

**Redis Error?**
```bash
# Check if Redis is running
redis-cli ping

# Start Redis with Docker
docker run -d -p 6379:6379 redis:latest
```

**Port 3000 in use?**
```bash
# Use different port
PORT=4000 npm start
```

**Worker not processing?**
- Make sure both producer AND worker are running
- Check worker terminal for errors

## 📚 Next Steps

- Read the full [README.md](README.md) for detailed documentation
- Check [examples.js](examples.js) for programmatic usage
- Run [demo.sh](demo.sh) for a comprehensive test

---

**Need help?** Check the main README.md for detailed documentation!
